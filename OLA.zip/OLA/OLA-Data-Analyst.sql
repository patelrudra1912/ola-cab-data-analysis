CREATE DATABASE ola;
USE ola;

DROP TABLE bookings;

CREATE TABLE bookings (
    Booking_ID VARCHAR(255),
    Date DATE,
    Time TIME,
    Booking_Status VARCHAR(100),
    Customer_ID VARCHAR(100),
    Vehicle_Type VARCHAR(100),
    Pickup_Location VARCHAR(255),
    Drop_Location VARCHAR(255),
    V_TAT FLOAT,
    C_TAT FLOAT,
    Canceled_Rides_by_Customer VARCHAR(255),
    Canceled_Rides_by_Driver VARCHAR(255),
    Incomplete_Rides VARCHAR(100),
    Incomplete_Rides_Reason TEXT,
    Booking_Value FLOAT,
    Payment_Method VARCHAR(50),
    Ride_Distance FLOAT,
    Driver_Ratings FLOAT,
    Customer_Rating FLOAT
);

SET GLOBAL local_infile = 1;

SHOW VARIABLES LIKE 'local_infile';

LOAD DATA LOCAL INFILE 'C:/Uploads/Bookings.csv'
INTO TABLE bookings
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

#1. Retrieve all successful bookings:

CREATE VIEW Successful_Bookings AS
SELECT * FROM bookings
WHERE Booking_Status = 'Success';

SELECT * FROM Successful_Bookings;

#2. Find the average ride distance for each vehicle type:

CREATE VIEW Average_Distance_Bookings AS
SELECT Vehicle_Type, AVG(Ride_Distance) AS Average_Distance
FROM bookings
GROUP BY Vehicle_Type;

SELECT * FROM Average_Distance_Bookings;

#3. Get the total number of cancelled rides by Driver:

CREATE VIEW cancelled_rides_by_Driver AS
SELECT COUNT(*) FROM bookings
WHERE Booking_Status = 'Canceled by Driver';

SELECT * FROM cancelled_rides_by_Driver;
  
#4. List the top 5 customers who booked the highest number of rides:

CREATE VIEW highest_number_of_rides AS
SELECT Customer_ID, COUNT(*) AS Total_Rides
FROM bookings
GROUP BY Customer_ID
ORDER BY Total_Rides DESC
LIMIT 5;

SELECT * FROM highest_number_of_rides;

#5. Get the number of rides cancelled by drivers due to personal and car-related issues:

CREATE VIEW cancelled_by_drivers AS
SELECT COUNT(*) AS Canceled_Rides_by_Driver
FROM bookings
WHERE Booking_Status = 'Canceled by Driver'
AND Canceled_Rides_by_Driver IN ('Personal & Car related issue');

SELECT * FROM cancelled_by_drivers;

#6. Find the maximum and minimum driver ratings for Prime Sedan bookings:

CREATE VIEW ratings AS
SELECT MAX(Driver_Ratings) AS Max_Ratings, MIN(Driver_Ratings) AS Min_Ratings
FROM bookings
WHERE Vehicle_Type = 'Prime Sedan';

SELECT * FROM ratings;

#7. Retrieve all rides where payment was made using UPI:

CREATE VIEW METHOD AS
SELECT * FROM bookings
WHERE Payment_Method = 'UPI';

SELECT * FROM METHOD;

#8. Find the average customer rating per vehicle type:

CREATE VIEW average_customer_rating AS
SELECT Vehicle_Type, AVG(Customer_Rating) AS Average_Customer_Rating
FROM bookings
GROUP BY Vehicle_Type;

SELECT * FROM average_customer_rating;

#9. Calculate the total booking value of rides completed successfully:

CREATE VIEW total_booking_value AS
SELECT SUM(Booking_Value) AS Total_Booking_Value
FROM bookings
WHERE Booking_Status = 'Success';

SELECT * FROM total_booking_value;

#10. List all incomplete rides along with the reason:

CREATE VIEW canceled_reason AS
SELECT Booking_ID, Booking_Status, Canceled_Rides_by_Customer
FROM bookings
WHERE Booking_Status != 'Success'
AND Canceled_Rides_by_Customer != 'NA';
SELECT * FROM canceled_reason;

#1. Retrieve all successful bookings:

SELECT * FROM Successful_Bookings;

#2. Find the average ride distance for each vehicle type:

SELECT * FROM Average_Distance_Bookings;

#3. Get the total number of cancelled rides by customers:

SELECT * FROM cancelled_rides_by_Driver;

#4. List the top 5 customers who booked the highest number of rides:

SELECT * FROM highest_number_of_rides;

#5. Get the number of rides cancelled by drivers due to personal and car-related issues:

SELECT * FROM cancelled_by_drivers;

#6. Find the maximum and minimum driver ratings for Prime Sedan bookings:

SELECT * FROM ratings;

#7. Retrieve all rides where payment was made using UPI:

SELECT * FROM METHOD;

#8. Find the average customer rating per vehicle type:

SELECT * FROM average_customer_rating;

#9. Calculate the total booking value of rides completed successfully:

SELECT * FROM total_booking_value;

#10. List all incomplete rides along with the reason:

SELECT * FROM canceled_reason;
